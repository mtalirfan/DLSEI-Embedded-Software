## Assignment 1: stats

Part of the Introduction to Embedded Systems Software and Development Environments Coursera course.

This program calculates the statistics of an array of unsigned char data items.

The statistics include:

- Mean
- Median
- Maximum
- Minimum

The program also sorts the array from largest to smallest.
The program can also print the array.

#### Created by mtalirfan
